#ifndef __APP_COMM_H__
#define __APP_COMM_H__

extern void SetComRcvNewFlg (unsigned char _cFlg);
extern unsigned char IsComRcvNew (void);
extern unsigned char IsComRcvDone(unsigned char _cDat);

#endif
