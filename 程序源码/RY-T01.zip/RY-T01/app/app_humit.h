#ifndef __APP_HUMIT_H__
#define __APP_HUMIT_H__

extern void Humit_Freq_Set(uint32_t _ifreq);
extern void Humit_FreqOver_Set(void);

#endif



