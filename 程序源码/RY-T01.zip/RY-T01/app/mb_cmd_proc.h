#ifndef __MB_CMD_PROC_H__
#define __MB_CMD_PROC_H__

extern uint8_t dealMbCmd(unsigned char cmd, int beginAddr, int regNum);

#endif

