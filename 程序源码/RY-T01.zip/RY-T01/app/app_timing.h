#ifndef _APP_TIMING_
#define _APP_TIMING_

extern void valve_ctrl(SYSTEM_STATE_E sysSta, int start);

#endif