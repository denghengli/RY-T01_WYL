#ifndef __DRIVER_TIMER_H__
#define __DRIVER_TIMER_H__

extern void Timing_Clock_Cnt(void);
extern void MX_TIM1_Init(void);
extern void MX_TIM2_Init(void);

#endif


