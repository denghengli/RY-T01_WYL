#ifndef _DRIVER_ADC_
#define _DRIVER_ADC_

extern void MX_ADC1_Init(void);

#endif


