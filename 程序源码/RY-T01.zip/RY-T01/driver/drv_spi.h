#ifndef __DRIVER_SPI__
#define __DRIVER_SPI__

extern void MX_SPI1_Init(void);

extern uint8_t spi1SendData(uint8_t txData);

#endif

